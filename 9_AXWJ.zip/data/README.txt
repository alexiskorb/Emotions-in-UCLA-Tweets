README
Group 9: AXWJ

Data:
-tweets.csv
	contains the raw text of all 20543 tweets gathered
-preprocessed_tweets.csv
	contains the text of all tweets after preprocessing (but including stopwords)
-preprocessed_tweets_modified.csv
	same data as preprocessed_tweets.csv, but put into a more usable format
-preprocessed_tweets_labels.csv
	labels for each of the tweets in preprocessed_tweets.csv
	each label at position k corresponds to the tweet at position k



